# Ring Clash 3D — لعبة مصارعة ثلاثية الأبعاد للهواتف (Godot 4.3+)

كل شيء مبني من أشكال أولية (بدون أي ملفات فنية خارجية)، والمشروع جرّبته فعليًا على Godot 4.7.2.

## تشغيل
Import → `project.godot` → F5.  (Renderer = Compatibility، مناسب لأغلب الهواتف)
لوحة المفاتيح للتجربة: WASD حركة، J لكمة، K ركلة، L مسك/تثبيت، Space دفاع، Shift ركض، Enter بدء.

## السكريبتات
| الملف | الوظيفة |
|---|---|
| `Fighter.gd` | الأساس المشترك: الهيكل، الأنيميشن (AnimationPlayer)، الصحة/الطاقة، آلة حالات القتال، Hitbox/Hurtbox، المسك والرمية والتثبيت |
| `Player.gd` | تحكم اللاعب: لوحة مفاتيح + `TouchControls`، حركة نسبةً للكاميرا |
| `EnemyAI.gd` | ذكاء الخصم: APPROACH / CIRCLE / ATTACK / DEFEND / RETREAT / FINISH |
| `CameraController.gd` | كاميرا ديناميكية تتبع المصارعَين وتقرّب/تبعّد حسب المسافة |
| `TouchControls.gd` | جويستيك عائم + أزرار PUNCH/KICK/GRAB/BLOCK بدعم لمس متعدد |
| `Arena.gd` | الحلبة، الجمهور (MultiMesh)، الإضاءة، الجدران |
| `Hud.gd` | أشرطة الصحة والطاقة والرسائل |
| `Main.gd` | بناء المشهد وسريان المباراة |

## شجرة العقد (Node Tree)
### المشهد الرئيسي
```
Main (Node3D)                  ← Main.gd
├─ Arena (Node3D)              ← Arena.gd
│  ├─ WorldEnvironment         (خلفية لون + إضاءة محيطة، بدون glow/SSAO)
│  ├─ DirectionalLight3D ×2    (بدون ظلال)
│  ├─ Ring: StaticBody3D (أرضية الحلبة) + MeshInstance3D
│  ├─ Posts / Ropes            (MeshInstance3D: Cylinder/Box)
│  ├─ Walls ×4                 (StaticBody3D غير مرئية عند الحبال)
│  ├─ Stands                   (MeshInstance3D Box لكل مدرج)
│  └─ MultiMeshInstance3D      (الجمهور: drawcall واحد)
├─ Player (CharacterBody3D)    ← Player.gd
├─ Enemy  (CharacterBody3D)    ← EnemyAI.gd
├─ Camera3D                    ← CameraController.gd
└─ CanvasLayer
   ├─ Hud (Control)            ← Hud.gd
   └─ TouchControls (Control)  ← TouchControls.gd
```
### المصارع (Player / Enemy)
```
Player (CharacterBody3D)        ← Player.gd (يرث Fighter.gd)
├─ Visual (Node3D)              ← يدور (Yaw) نحو الخصم
│  ├─ Body (Node3D)             ← مركزه الورك؛ ينحني/يسقط عبره الأنيميشن
│  │  ├─ MeshInstance3D         (السروال)
│  │  ├─ Torso (Node3D)
│  │  │  ├─ MeshInstance3D      (الصدر)
│  │  │  ├─ Head → MeshInstance3D ×2 (رأس + شعر)
│  │  │  ├─ ShL → MeshInstance3D + ElL → (ساعد + قفاز)
│  │  │  └─ ShR → MeshInstance3D + ElR → (ساعد + قفاز)
│  │  ├─ HipL → MeshInstance3D + KnL → (ساق + حذاء)
│  │  └─ HipR → MeshInstance3D + KnR → (ساق + حذاء)
│  └─ Hitbox (Area3D)           ← مجال الضربة؛ mask = طبقة Hurtbox الخصم، يُفعَّل فقط في نافذة الضرر
│     └─ CollisionShape3D (Sphere)
├─ CollisionShape3D (Capsule)   ← فيزياء الحركة
├─ MeshInstance3D               ← ظل دائري رخيص بدل ظلال حقيقية
├─ Hurtbox (Area3D)             ← layer = 2 (فريق 0) أو 4 (فريق 1)
│  └─ CollisionShape3D (Capsule)
└─ AnimationPlayer              ← أنيميشن: idle, walk, run, punch, kick, hit, block,
                                  grab, hold, slam, carried, down, getup, pin, win
```
الأنيميشن مولَّدة بالشيفرة (`_build_anims`) على مفاصل `rotation_degrees`، فيمكنك فتحها وتعديلها لاحقًا. لاستبدال المجسّم بنموذج حقيقي: ضع `Skeleton3D` بدل `Visual/Body`، واربط الحركات بـ `AnimationTree` (State Machine بنفس الأسماء أعلاه) واترك بقية المنطق كما هو.

### الواجهة (UI)
```
CanvasLayer (layer = 10)
├─ Hud (Control, Full Rect)             ← Hud.gd  (mouse_filter = Ignore)
└─ TouchControls (Control, Full Rect)   ← TouchControls.gd
```
في المحرر فعّل: Project Settings → Input Devices → Pointing → **Emulate Touch From Mouse** (مفعّل في هذا المشروع) لتجربة اللمس بالفأرة.

## كيف يعمل القتال
* **Hitbox/Hurtbox:** أثناء نافذة الضرر في اللكمة/الركلة يُفعَّل `Hitbox` (Area3D)، وإذا تداخل مع `Hurtbox` الخصم يُنفَّذ `take_hit`.
* **المسك:** GRAB قرب الخصم ← يرفعه فوق الكتفين ← رمية (Slam/Suplex) بضرر كبير. عند امتلاء شريط الـ Special تصبح الرمية القاضية.
* **التثبيت:** GRAB والخصم ساقط وقريب ← عدّ 1-2-3 مع فرصة خروج تعتمد على صحته وطاقته. **PINFALL** أو **K.O.** ينهي المباراة.
* **Block:** يخفّض الضرر ويستهلك الطاقة؛ المسك يتجاوزه.

## نصائح أداء للهواتف (هدف 60 FPS)
1. استخدم **Compatibility** (OpenGL ES 3) أو Mobile؛ تجنّب Forward+ على الأجهزة المتوسطة.
2. **بدون ظلال حقيقية** (`shadow_enabled=false`) واستعمل ظلًّا دائريًا مزيفًا تحت المصارع. لو احتجت ظلًا: ضوء اتجاهي واحد فقط، `directional_shadow/size=1024`، `max_distance` قصير، و`PSSM 1 split`.
3. عدد الأضواء ≤ 2، ولا OmniLight/SpotLight مع ظلال.
4. `shading_mode = PER_VERTEX` للمواد، وتجنّب Transparency/Alpha Scissor قدر الإمكان (الظل الدائري هو الشفاف الوحيد).
5. **MultiMesh** للجمهور (drawcall واحد) بدل مئات العقد.
6. عطّل MSAA وSSAO وGlow وSSR وVolumetric Fog؛ استخدم FXAA فقط إن لزم.
7. اجعل الـ Meshes منخفضة التفاصيل (≤ 8 radial segments) وأعد استخدام Materials.
8. للنماذج الحقيقية: ≤ 10-15k مثلث للمصارع، عظام ≤ 60، خامات ASTC/ETC2 بحجم 1024 كحد أقصى، وAtlas واحد لكل شخصية.
9. لا تعمل `get_overlapping_areas()` إلا أثناء نافذة الضرر (هكذا يفعل المشروع)، وفعّل `Physics Jitter Fix`/`physics_ticks_per_second=60` فقط.
10. صدّر بـ **Gradle Build** مع arm64-v8a فقط، وفعّل `Use 32 Bits Framebuffer` إلا إذا احتجت HDR.
11. قِس بـ Debugger → Monitors على جهاز حقيقي؛ المرمى: Draw calls < 150، Vertices < 150k.

## التصدير لأندرويد
Project → Export → Android (يحتاج JDK + Android SDK + Export Templates):
https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html
اللعبة بالوضع الأفقي (Landscape).

---
## النماذج الحقيقية (Randy Orton / AJ Styles) — تحديث
* الملفان في `models/orton.glb` و`models/aj.glb` (خاماتهما مصغَّرة إلى 512px لتناسب الهاتف بواسطة `tools/shrink_glb.py`؛ ضع الأصليين في `original/` ثم شغّله).
* **الترخيص:** ملفا RigModels المرفقان مرخَّصان **للاستخدام الشخصي (طلاب) فقط**، والنموذجان لأشخاص حقيقيين. لا تنشر اللعبة ولا تصدّرها تجاريًا بهما؛ للنشر استبدلهما بنماذج مرخَّصة.
* **الحركات:** النموذجان يملكان حركة جري واحدة فقط، فبنيتُ كل حركات المصارعة (idle, walk, run, punch, kick, hit, block, grab, hold, slam, carried, down, getup, pin, win) برمجيًا: `Fighter.gd` يحوّل أوضاع المفاصل إلى عظام النموذج (Forward Kinematics) مع تثبيت القدمين على الأرض تلقائيًا.
* لاستخدام نموذجك الخاص: اضبط `model_path` و`model_height` في `ROSTER` داخل `Main.gd`. يلزم هيكل عظمي بأسماء Auto-Rig Pro (`rootx, spine_01x, arm_stretchl, forearm_stretchl, thigh_stretchl, leg_stretchl, footl, toes_01l, neckx, headx ...`)، ولهيكل آخر عدّل جدول الأدوار في `_cache_rig()`.
* **أداة المعاينة:** `scenes/Gallery.tscn` تعرض كل حركة كصورة ثابتة: `godot --path . res://scenes/Gallery.tscn -- --model=res://models/aj.glb --height=1.8 --out=/tmp/gallery`

---
## تحديث: حركات Mocap حقيقية + اختيار الشخصية
* الحركات الآن من حزم Motifect و Haley (BVH) منقولة (Retarget) إلى عظام Orton و AJ عبر `tools/retarget.py`؛ النتيجة في `anims/orton.json` و `anims/aj.json` وتُبنى وقت التشغيل بواسطة `scripts/AnimLib.gd`.
* لكل شخصية حركاتها: **كومبو لكمات** (P1→P2→P3 بالضغط المتتابع)، **كومبو ركلات**، **ضربة الجري** (جري + لكمة)، **Special** (عند امتلاء الشريط الأصفر) و**رمية قاضية** (GRAB وهو ممتلئ).
* أزرار جديدة: SPECIAL (لوحة المفاتيح U) و DODGE (O).
* ردود فعل الوجع: 4 حركات ألم + سقوط + قيام، مع وميض أحمر، هزّة كاميرا، توقف لحظي (Hit-stop) وشرارات.
* فيزياء: دفع بين المصارعين حسب الكتلة، ارتداد من الحبال، تجاوز الأجساد الساقطة، وتقدّم تلقائي نحو الخصم عند الضرب.
* شاشة اختيار الشخصية في البداية (اضغط على المصارع أو A/D + Enter).

## تحديث 2: حركات Mixamo (KimiClaw)
* حركات Mixamo (Punching, Elbow Punching, Kicking, Side Kick, Drop Kick, Flying Knee Punch Combo, Running, Big Hit To Head, Stunned) منقولة إلى **AJ وRandy Orton معًا** (مجلد `kimi/` للمصدر).
* AJ: Drop Kick كـ Special، Flying Knee عند الجري + لكمة. Orton: Flying Knee كـ Special، Lariat عند الجري + لكمة.
* الجري صار من Mixamo، والضرب في الرأس والـ KO من Mixamo.
* مصدر النقل: `tools/dump_mixamo.gd` (استخراج الحركات من FBX داخل Godot).

## تحديث 3
* Orton: ضربة رأس (Headbutt) في الكومبو، وركلة Muay Thai Roundhouse كركلة ثالثة.
* AJ: ركلة Hurricane كركلة ثالثة.

## تحديث 4: رميات السوبليكس
* GRAB العادي = Vertical Suplex: يرفع الخصم مقلوبًا فوق رأسه ثم يسقط للخلف ويضربه على ظهره.
* GRAB مع الشريط الأصفر ممتلئ = رمية خاصة: Orton ← RKO (قفز وقلب الخصم)، AJ ← Styles Clash (قلب الخصم فوق الكتف).
* للاختبار: `--autotest --pick=0 --grab=normal|big`.

---
## الإصدار 7
- **قوائم:** شاشة بداية (START / OPTIONS / EXIT)، صفحة Options فيها **صعوبة المباراة** (EASY / NORMAL / HARD)، واختيار المصارع في **3 صفحات**: 1) مصارعك 2) الخصم 3) إعداد المباراة (الصعوبة + START MATCH). أزرار BACK/NEXT وتعمل باللمس والكيبورد. شاشة النتيجة: REMATCH / MAIN MENU. (Esc أثناء المباراة = القائمة الرئيسية)
- **الخسارة بالتثبيت فقط:** نفاد الطاقة لا ينهي المباراة؛ المصارع يسقط (EXHAUSTED) ولا ينهض حتى تعود طاقته إلى 15%. الطاقة **تعود تلقائيًا** عندما يتوقف الخصم عن ضربه (بعد 1.5 ثانية)، ولا تعود أثناء التثبيت.
- **Reverse للإمساك:** عند Head Lock يستطيع المدافع قلبها إلى رمية رفع أخرى (Suplex / Body Slam / Tiger Driver / Piledriver / Rib Breaker / Powerslam) بضرر أعلى. اللاعب: اضغط GRAB (أو BLOCK) أثناء القفل؛ الذكاء الاصطناعي بنسبة حسب الصعوبة. الفينشر والسبيشل لا تُعكس.
- **زر الاحتفال TAUNT** (مفتاح T / زر على الشاشة): يملأ ~40% من شريط الفينشر، وتُقاطَع عند تلقي ضربة.
- **تحسينات التأثيرات:** غبار + اهتزاز أقوى + توقف لحظي عند الرميات (Powerbomb وغيرها)، وإزالة تكرار أرقام العدّ في التثبيت.
- أعلام اختبار جديدة: `--rev` (فرض الـ Reverse) · `--taunt` · `--lowhp=0.05` · `--menu=options,diff+,back,start,confirm,...`

---
## الإصدار 8 — مكتبات WWE2011 الجديدة (RR02 + RR03)
**ما هي المكتبتان:** 714 ملف FBX (ASCII) بلا أسماء حركات (أرقام فقط)، وفيها دوران العظام فقط (30 عظمة). مستورد FBX في Godot يفشل مع معظمها (`Threaded ASCII parse error`)، فكتبتُ قارئًا خاصًا (`tools/wwe_pipeline/fbxparse.py`) يحسب مواضع المفاصل، تحققت أنه يطابق Godot تمامًا.
**أداة النقل إلى عظام اللاعبين:** `tools/wwe_retarget.gd` تنقل أي حركة إلى الشخصيات الأربع، وتحافظ على موضع المنفّذ والمتلقي معًا في الأزواج.
**ما دخل اللعبة الآن:** حركة ضرب أرضية جديدة (g3: ضربة كوع/ركبة من الأعلى على الخصم الساقط، رقم المصدر 10514) لكل المصارعين الأربعة.
**لم يدخل بعد:** لم أجد في المكتبة باور بومب واضح ولا وضع تثبيت واضح (لا توجد أسماء)، لذلك بقيت حركات الباور بومب والتثبيت القديمة. أدوات `pairview.sh` و `single.sh` تعرض أي رقم بصور لاختيار حركات أخرى.

## الإصدار 9 — رميات رفع جديدة من WWE2011
استُبدلت **Powerbomb** و **Attitude Adjustment** و **Suplex** (لكل المصارعين الأربعة) برميات رفع من المكتبتين الجديدتين: powerbomb ← 7202 (رفع وقلب فوق الرأس ثم سقوط على الظهر)، aa ← 7210 (رفع عالٍ ثم رمي)، suplex ← 7357 (رفع وقلب للخلف). تُنتج بـ `tools/wwe_pipeline/build_lifts.py` (يمكن تغيير الأرقام في MOVES). القيد: اللعبة تدعم فقط نهايات يكون فيها الخصم على ظهره (supine).

## الإصدار 10 — رميات رفع حقيقية مربوطة باللاعبين + مجلدا RR00/RR01
**المشكلة التي حُلّت:** اللاعب والخصم كانا يظهران في مكانين مختلفين أثناء الرمية. السبب: (1) بعض الحركات المختارة سابقًا كانت أصلًا "قذفًا" للخصم بعيدًا عن المصارع، (2) اختلاف أطوال المصارعين، (3) دوران الخصم عند بداية الرمية كان يحرّك موضعه فجأة.
**الحل:**
- `Fighter._attach_victim`: أثناء الحمل يُلصق الكود وركَي الخصم بيدي المصارع الفعليتين (مهما اختلف الحجم)، ويثبّت موضع الخصم في الإطار المشترك أثناء الانتقال من القفل إلى الرمية.
- اختيار الحركات بفحص آلي: أن يبدأ الخصم من وضع قريب من قفل الرأس، وأن يكون محمولًا فعلًا بيدي المصارع ≥ 55% من فترة الرفع، وأن ينتهي على ظهره.
**الحركات الجديدة (4 مصارعين):** Powerbomb ← RR01 5533، Attitude Adjustment ← RR01 5787 (حمل على الكتفين ثم رمي)، Suplex ← RR01 5505.
**RR00/RR01:** حُوّلت كلها (1684 ملفًا). وجدت غطاءً حقيقيًا للتثبيت (RR01 6034) لكن لا يوجد له kickout مطابق، فلم أستبدل التثبيت الحالي كي لا ينكسر. حركات الأرض المتاحة كلها ضربات ركبة/كوع من الأعلى (مثل g3 الحالية).

## الإصدار 11
- **German Suplex من الخلف:** عند اختيار السوبليكس يتحرك المصارع بقوس إلى خلف الخصم ويمسكه من الخصر ثم يرميه للخلف (`_begin_rear` / `_rear_tick` في Fighter.gd، تفعّلها `rear=true` في بيانات الحركة).
- **إيقاع اللعب:** تباطؤ تشغيل الحركات حسب نوعها (الضربات الخفيفة أسرع، الركلات والرميات أثقل) عبر `_pace_factor`، وتقليل سرعة المشي والجري، وزيادة تنوع تفكير الخصم (أحيانًا سريع وأحيانًا يتوقف لحظة).
- **السقوط:** المصارع الساقط لم يعد متجمدًا: ترتخي أطرافه إلى وضع استلقاء طبيعي ثم يتنفس ويتحرك قليلًا، وبشكل أقوى عند الإنهاك أو عند ضربه على الأرض (`_lie_fx`).

## الإصدار 12 — حركات رفع جديدة بأسماء مؤكدة قدر الإمكان
**اكتشاف مهم:** رقم كل ملف في مكتبات WWE2011 = رقم حركة لعبة SvR2010/2011 بالنظام العشري (مثال: 7392 = 0x1CE0 = «Back Suplex 7»؛ 7306 = «Electric Chair Drop»). قوائم الأسماء على الإنترنت تغطي فقط نحو 35 رقمًا موجودًا في المكتبات.
**الحركات المستخدمة الآن:**
- Suplex ← **Back Suplex 7** (w7392) — الاسم مؤكد من القائمة وبالمشاهدة. 
- AA ← b5158 (0x1426): حمل على الكتفين مع دوران ثم رمي (تعرّفتُ عليها بالمشاهدة، الاسم غير مؤكد).
- Powerbomb ← a2623 (0x0A3F): رفع على الكتف ثم رمي (أقرب حركة وجدتها؛ ليست باور بومب كلاسيكية).
**عام:** كل رمية جديدة تبدأ الآن بانتقال: المصارع يلتف إلى مكان بدء الحركة والخصم ثابت، والخصم يُربط بيدي المصارع حتى لحظة الارتطام.

## الإصدار 13 — حركات بأسماء حقيقية (من جدول misc.pac)
أرقام الملفات = أرقام الحركات (عشريًا) في ملف الأسماء الذي أرسلتَه. استُعملت:
- **Powerbomb 5** (5547): رفع الخصم عاليًا ثم دقه على ظهره.
- **Attitude Adjustment 2** (5010): حمل على الكتفين ثم رمي.
- **Suplex 2** (5062): سوبليكس عمودي (الخصم مقلوب فوق المصارع ثم يسقطان للخلف).
ملاحظات: AA 1 وAA 3 وGerman Suplex 1 جرّبتها فوجدت أن الخصم يطير بعيدًا بلا إمساك (بيانات الخصم غير متطابقة مع المصارع) فلم أستعملها. تُقصّر الأداة فترات الإمساك الساكنة تلقائيًا، وتنهي الحركة عندما يستقر الخصم على الأرض، وتقرّب مكان هبوطه (≤1.7م) من المصارع.

## الإصدار 14 — تصحيح موضع الخصم أثناء الرفع
- **السبب:** كان الكود يلصق وركَي الخصم بيدي المصارع المنقولتين، وهما لا تطابقان يدَي الحركة الأصلية، فكان الخصم يُسحب بعيدًا عن مكانه الصحيح. أُلغي هذا الربط (`USE_HAND_ATTACH=false`) واعتُمد موضع الخصم كما في الحركة الأصلية، مع تحجيم مساره إلى حجم المصارع المنفِّذ (`_attach_victim`). قِستُ الموضع داخل اللعبة وفي عارض الحركات فتطابقا.
- **Powerbomb:** استُبدلت بـ **Sitout Powerbomb** (5357): يجلس الخصم على كتفَي المصارع ثم يُدقّ على ظهره والمصارع يجلس (التعريف القياسي للباور بومب). حركة Powerbomb 5 كانت تحمل الخصم أمامه لا على كتفيه.
- AA 2 (حمل على الكتفين) وSuplex 2 (خصم مقلوب فوق المصارع) بقيتا لأن وضع الخصم فيهما مطابق للتعريف.

## الإصدار 15 — العودة إلى المكتبة الأولى (anims/library)
استُبدلت الحركات الثلاث بحركات من المكتبة الأولى، وهي تعمل في مكان واحد للاعبين (الخصم يُحمل فعلًا على الكتفين):
- **Powerbomb** ← `Powerbomb` (PowerbombOffense/Defense_Update): انحناء، رفع الخصم على الكتفين، ثم دقّه على ظهره.
- **Attitude Adjustment** ← `GrappleBack_FalconArrow`: حمل الخصم على الكتفين ثم رميه.
- **Suplex** ← `GrappleBack_GermanSuplex`: المصارع يأتي خلف الخصم، يمسكه من خصره ويرميه للخلف (German Suplex).
الأداة: `tools/wwe_pipeline/build_from_library.py` (يمكن تغيير أسماء الحركات في MOVES؛ أي زوج _Offense/_Defense في anims/library/aj و orton). المصارعان Boxer وRunner يستعملان حركات aj مع ضبط الوضع.
إصلاح إضافي: ملف rest-pose للمصارعين الذين لديهم عظمة spine_04x (orton, boxer, runner) كان يُحسب خطأ مما يربك اتجاه استلقاء الخصم، وصُحّح.

## الإصدار 16 — استبدال Suplex / Powerbomb / Attitude Adjustment بحركات أخرى من المكتبة
- **Suplex** ← `GrappleBack_DragonSuplex` (إمساك من الخلف، رفع وقلب الخصم فوق الرأس ليهبط على بطنه).
- **Powerbomb** ← `GrappleBack_FalconArrow` (رفع الخصم مقلوبًا على الكتفين ثم دقّه على ظهره).
- **Attitude Adjustment** ← `GrappleBack_FullNelsonSlam` (رفع الخصم عاليًا من الخلف ثم رميه على ظهره).
- تمت المراجعة بصريًا داخل Godot 4.7.2 (AJ/Orton/Boxer/Runner): الاثنان في نفس المكان طوال الحركة، يهبط الخصم على الحلبة ثم ينهض.
- علم اختبار جديد: `--norev` يمنع الـ Reverse العشوائي أثناء فحص الحركات.
- إعادة التوليد: عدّل `MOVES` في `tools/wwe_pipeline/build_from_library.py`.
