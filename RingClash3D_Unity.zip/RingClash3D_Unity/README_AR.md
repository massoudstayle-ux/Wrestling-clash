# Ring Clash 3D — Unity Port

هذه حزمة بداية لنقل لعبة Godot إلى Unity 2022.3 LTS.

## ما تم تضمينه
- نماذج الشخصيات: AJ وOrton وBoxer وRunner بصيغة GLB.
- خامات النماذج الأصلية.
- ملفات FBX لحركات Mixamo.
- مكتبات الأنميشن المعاد نقلها بصيغة JSON.
- تقرير فحص الأنميشن ووثائق المشروع الأصلي.

## الخطوة التالية داخل Unity
1. أنشئ مشروع Unity 2022.3 LTS (URP أو 3D Mobile).
2. انسخ مجلد `Assets/RingClash3D` إلى مجلد `Assets` في مشروعك.
3. ثبّت glTFast من Package Manager لاستيراد GLB، أو حوّل النماذج إلى FBX.
4. اربط ملفات FBX بالـ Animator Controller.
5. ستتم إعادة كتابة Fighter وPlayer وEnemyAI وArena وHUD كـ C#.

## ملاحظة
ملفات Godot GDScript وTSCN لا تعمل في Unity، لذلك هذه ليست عملية تحويل آلي؛ الأصول والأنميشنات قابلة لإعادة الاستخدام، أما منطق اللعبة فيعاد بناؤه.
